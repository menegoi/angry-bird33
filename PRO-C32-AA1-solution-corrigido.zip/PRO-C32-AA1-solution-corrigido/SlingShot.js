class SlingShot{

//Criar propriedades
constructor(bodyA, pontoB){
    //Adicionar opções para as propriedades que serão adicionadas a Constraint
    var options = {
    bodyA: bodyA,
    pointB: pontoB,
    stiffness: 0.04,
    lenght: 10
    }

  // Criar restrição entre Angry Bird e um ponto
  this.pontoB = pontoB;
  this.sling = Constraint.create(options);

  //Carregar imagens da catapulta
  this.imgSling1 = loadImage("sprites/sling1.png");
  this.imgSling2 = loadImage("sprites/sling2.png");
  this.imgSling3 = loadImage("sprites/sling3.png");

  //Adicionar sling ao mundo
  World.add(mundo, this.sling);

}

//Criar funções

//Função que faz o Angry Bird voar
fly(){
  this.sling.bodyA = null;
}

//Função para reconectar Angry Bird ao estilingue
reconectar(bodyA){
  this.sling.bodyA = bodyA;
}
//Função que faz os elementos serem mostrados na tela
display(){

    if(this.sling.bodyA){
    var pontoA = this.sling.bodyA.position;
    var pontoB = this.pontoB;

    //Linha conectando Angry Bird ao tronco
    //strokeWeight(3);
    //line(pontoA.x, pontoA.y,pontoB.x, pontoB.y);

    //Desenhar linha do elástico
    push();
    //Definir cor do elástico
    stroke("rgb(48,22,8)");

    if( pontoA.x < 220){
      strokeWeight(4);
      line(pontoA.x - 20, pontoA.y, pontoB.x -10, pontoB.y);
      line(pontoA.x - 20, pontoA.y, pontoB.x + 30, pontoB.y -3);
      image(this.imgSling3,pontoA.x - 30,pontoA.y-10, 15,30);

    }else{
      strokeWeight(3);
      line(pontoA.x - 25, pontoA.y, pontoB.x -10, pontoB.y);
      line(pontoA.x - 25, pontoA.y, pontoB.x + 30, pontoB.y -3);
      image(this.imgSling3,pontoA.x - 25,pontoA.y-10, 15,30);
    }



    pop();

    }

  //Adicionar imagens da catapulta
  image(this.imgSling1,200,20);
  image(this.imgSling2,170,20);
}


}