class Box extends BaseClass{

    //Propriedades
    constructor(x,y,width,height){


        //Criar o objeto caixa
        super(x,y,width,height);
        this.image = loadImage("sprites/wood1.png");
    }

}