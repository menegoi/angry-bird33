//Crir Variáveis
var mecanismo, mundo;
var caixa1,caixa2, caixa3, caixa4, caixa5;
var solo, angryBird;
var porco1, porco2;
var tronco1, tronco2,tronco3,tronco4;
var  imgPanoDeFundo;
var plataforma;
//var restritoLog;
var estilingue;
var score = 0;

//Estado do jogo
var gameState = "noEstilingue";

//Criar constantes
const World = Matter.World;
const Engine = Matter.Engine;
const Bodies = Matter.Bodies;
const Body = Matter.Body;
const Constraint = Matter.Constraint;

function preload(){
 imgPanoDeFundo = loadImage("sprites/bg.png");
 getBackground();
}

function setup() {
  //Criar área de jogo
  createCanvas(1200,400)

  //Criar mecanismo de física e mundo
  mecanismo = Engine.create();
  mundo = mecanismo.world;

  //Criar Solo
  solo = new Ground(width/2,390,width, 20);
  plataforma = new Ground(150, 305,300,170);

  //Criar pássaro Angry Bird
  angryBird = new Bird(200,50);

  //Nível 1 Caixas e POrco
  caixa1 = new Box(800,355,50,50);
  caixa2 = new Box(1000,355,50,50);
  porco1 = new Pig(900,355);

  //Nível 2 Tronco
  tronco1 = new Log(900,320,250,0);

  //Nível 3 Caixas e Porcos
  caixa3 = new Box(800,285,50,50);
  caixa4 = new Box(1000,285,50,50);
  porco2 = new Pig(900,285);

  //Nível 4 Tronco
  tronco2 = new Log(900,250,250,0);

  //Nível 4 caixa e troncos
  caixa5 = new Box(900,215,50,50);  
  tronco3 = new Log(860,210,95,-PI/7);
  tronco4 = new Log(940,210,95,PI/7);

  //Criar objetos com restrição
  //restritoLog = new Log(230,180,80,0);
  estilingue = new SlingShot(angryBird.body,{x:200, y:50});


}
function draw() {

  if(imgPanoDeFundo){
    //Limpar a tela
    background(imgPanoDeFundo);
  }

  //Pontuação
  push();
  noStroke();
  textSize(25);
  fill("white");
  text("Pontuação " + score,1000,50)
  pop();


  //Atualizar o mecanismo de física
  Engine.update(mecanismo);
 
  // Mostrar o solo na tela
  solo.display();

  //Mostrar Angry Bird na tela
  angryBird.display();

  //Mostrar nível 1 - Caixas e porco
  caixa1.display();
  caixa2.display();
  porco1.display();
  porco1.updateScore();

  //Mostrar nível 2 - Tronco
  tronco1.display();
  
  //Mostrar nível 3 - Caixas e Porco
  caixa3.display();
  caixa4.display();
  porco2.display();
  porco2.updateScore();

  //Mostrar nível 4 - troncos
  tronco2.display();

  //Mostrar nível 5 - Caixa e troncos
  caixa5.display();  
  tronco3.display();
  tronco4.display();

  //Mostrar plataforma
  plataforma.display();

  //Mostrar elementos restritos
  //restritoLog.display();
  estilingue.display();

  //Mostrar na tela a posição do mouse
  push();
  fill("white");
  text("Posição: ("+ mouseX + "," + mouseY+")",  10, 20);
  pop();

}
function mouseDragged(){
  //Verificar se o jogo esta no estado "noestilingue"
  if(gameState === "noEstilingue"){
  Body.setPosition(angryBird.body, {x: mouseX,y:mouseY});
  }
}
function mouseReleased(){
  estilingue.fly();

  //Mudar estado de jogo quando pássaro é lançado
  gameState = "projetado";
}
function keyPressed(){

  if(keyCode === 32){
    //Fazer pássaro reconectar ao estilingue
    estilingue.reconectar(angryBird.body);
    Body.setPosition(angryBird.body, {x: 200,y:50});

  }
}
async function getBackground(){
  //Fazer chamada API
  var response = await fetch("http://worldtimeapi.org/api/timezone/Asia/Tokyo");
  responseJSON = await response.json();

  //Dividir a string do atributo "datetime" para mostrar somente a hora
  var datetime = responseJSON.datetime;
  var hour = datetime.slice(11,13);
  console.log(hour);
  
  if(parseInt(hour) >= 6 && parseInt(hour) <=19){
    bg = "sprites/bg.png";
    
  }else{
    bg = "sprites/bg2.png";
  }
  imgPanoDeFundo = loadImage(bg);

 } 
