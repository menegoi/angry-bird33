class Pig extends BaseClass{

    //Propriedades
    constructor(x,y){

        super(x,y,50,50);
        this.image = loadImage("sprites/enemy.png");
        this.Visibility = 255;
    }

    display(){

        push();
        //console.log(this.body.speed);
    
        //Fazer porcos desaparecerem quando colidir com Angry Bird
        if(this.body.speed < 3){
            //Exibir porco pela função display() da classe mãe
            super.display();
    
        }else{
            World.remove(mundo, this.body);
            //push();
            //Definir nova tonalidade e redesenhar porco desaparecendo a cada quadro
            this.Visibility = this.Visibility - 5;
            tint(255,this.Visibility);
            image(this.image,this.body.position.x,this.body.position.y, 50,50);
            //pop();
    
        }

        pop();
    
    }

    updateScore(){
        if(this.Visibility < 0 && this.Visibility> -1005){
            score++;
        }
    }
    
}